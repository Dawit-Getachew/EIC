export enum CountryCodeName {
  ET = "et",
};


export enum CountryCode {
  ET = "+2519",
}


export enum CountryPhoneNumberLength {
  ET = 13,
}

export enum CountryName {
  ET = "Ethiopian",
}