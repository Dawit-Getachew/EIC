export enum Rule {
    STRING = "string",
    NUMBER = "number",
    REQUIRED = "required",
    EMAIL = "email",
    PHONE = "phone",
}