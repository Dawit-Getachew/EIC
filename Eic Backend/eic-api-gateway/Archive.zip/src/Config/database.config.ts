// load database config information from enviroment.
export const database = {
    databaseName: process.env.DATABASE_NAME,
    databaseHost: process.env.DATABASE_HOST,
    databasePort: process.env.DATABASE_PORT,
};
