import { Authorization } from '../../../Helpers/authorization';
import { IPostUser, ISigninUser } from '../../../Models/User/user.types';
import { IBasicID, IBasicIDs } from '../../../Common/interface';
import { UserService } from "../../../Services/UserService";
import { UserActions } from '../../../Graphql/Schema/User/action';

const {
  Query: { fetchAll, fetchManyByID, fetchOneByID },
  Mutation: { edit, login, logout, post, removeOne, removeMany, removeAll }
} = UserActions

const UserResolver = {
  Query: {
    async [fetchAll]() {
      return (await UserService.fetchUsers());
    },
    async [fetchOneByID](_: any, data: IBasicID) {
      return (await UserService.fetchOneUserByID(data));
    },
    async [fetchManyByID](_: any, data: IBasicIDs) {
      return await UserService.fetchManyUsersByID(data)
    }
  },
  Mutation: {
    async [post](_: any, data: any, context: any) {
      return await UserService.postUser(data, context)
    },

    async [login](_: any, data: ISigninUser, context: any) {
      return await UserService.signInUser(data, context)
    },

    async [logout](_: any, data: any, context: any) {
      await context.request.req.session.destroy();// destroy session.
      return { __typename: "Message", message: "Signed out successfully." };
    },

    async [edit](_: any, data: any, context: any) {
      return (await UserService.editUser(data));
    },

    async [removeMany](_: any, data: any) {
      return await UserService.removeManyUser(data)
    },

    async [removeOne](_: any, data: any) {
      return await UserService.removeUser(data)
    },

    async [removeAll](_: any, data: any) {
      return await UserService.removeAllUsers()
    },
  }
}

export default UserResolver