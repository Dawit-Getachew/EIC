import { IBasicID, IBasicIDs } from "../../../Common/interface";
import { BusinessProfileActions } from "../../../Graphql/Schema/BusinessProfile/action";
import { BUSINESS_PROFILE_QUEUES } from "../../../Common/queue_names"
import { BusinessProfileRoutes } from "../../../Common/routes"
import { RabbitMQProducer } from "../../../Connections/RabbitMQ/rabbitmq_producer";

const {
  Query: { fetchAll, fetchManyByID, fetchOneByID },
  Mutation: { edit, post, removeOne, removeMany, removeAll }
} = BusinessProfileActions

const BusinessProfileResolver = {
  Query: {
    async [fetchAll]() {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.GET_ALL_BUSINESS_PROFILES,
        data: {}
      }) as unknown as string;
      return JSON.parse(response)
    },
    async [fetchOneByID](_: any, data: IBasicID) {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.GET_ONE_BUSINESS_PROFILE,
        data
      }) as unknown as string;
      return JSON.parse(response)
    },
    async [fetchManyByID](_: any, data: IBasicIDs) {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.GET_MANY_BUSINESS_PROFILES_BY_ID,
        data
      }) as unknown as string;
      return JSON.parse(response)
    }
  },
  Mutation: {
    async [post](_: any, data: any, context: any) {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.POST_BUSINESS_PROFILE,
        data
      }) as unknown as string;
      return JSON.parse(response)
    },

    async [edit](_: any, data: any, context: any) {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.EDIT_BUSINESS_PROFILE,
        data
      }) as unknown as string;
      return JSON.parse(response)
    },

    async [removeMany](_: any, data: IBasicIDs) {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.REMOVE_MANY_BUSINESS_PROFILES_BY_ID,
        data
      }) as unknown as string;
      return JSON.parse(response)
    },

    async [removeOne](_: any, data: IBasicID) {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.REMOVE_BUSINESS_PROFILE_BY_ID,
        data
      }) as unknown as string;
      return JSON.parse(response)
    },

    async [removeAll](_: any, data: any) {
      const response = await RabbitMQProducer.sendRequestAndReceiveResponse(BUSINESS_PROFILE_QUEUES.QUEUE_FOR_BUSINESS_PROFILE, {
        route: BusinessProfileRoutes.REMOVE_ALL_BUSINESS_PROFILES,
        data: {}
      }) as unknown as string;
      return JSON.parse(response)
    },
  }
}

export default BusinessProfileResolver