import { gql } from "apollo-server-express"

export default gql`
    scalar Date
    type Query {
        _: Boolean
    }

    type Mutation {
        _: Boolean
    }

    type Subscription {
        _: Boolean
    }

    enum Gender {
        MALE 
        FEMALE
    }

    enum IRoleAccount {
        SUPER_ADMIN
        ADMIN
        TESTING
    }
    
    enum IRole {
        ADMIN
        USER
        TESTING
    }

    enum Unit {
        SQUARE_METERS
    }

    enum ProjectStages {
        INITIAL
    }

    enum CurrencyTypes {
        BIRR
        DOLLAR
    }

    type Error {
        error_code: Int
        error_message: String!
    }

    # Use for providing validation error during signup if the provided user information fails server side validation.
    # @error_path tells the which field of the input form failed during validation and the @errors provide error message.
    type ValidationError  {
        errors: [Error]
        error_path: String
    }

    # It simply Provide list of @ValidationError models.
    # use when declaring union. B/c union declaration doesn't support array(list).
    type ValidationErrors {
        validation_errors: [ValidationError!]
    }

    # use when we want to notify that a service is down.
    # @error_resource tell which service was call and it is not responding.
    type SystemError {
        error_code: Int
        error_message: String!
        error_resource: String
        error_source: String!
    }

    type SessionError {
        error_message: String
    }

    type UnAuthorizationError {
        error_message: String!
        status: Int
    }

     type UnAuthenticatedError {
        error_message: String!
        status: Int
    }

    type Message {
        message: String!
    }

    input AddressInput {
        sub_city: String!
        city: String!
        kebele: String!
    }

    input AddressEdit {
        sub_city: String
        city: String
        kebele: String
    }

    type IAddress {
        sub_city: String
        city: String
        kebele: String
    }

    type Count {
        amount: Int
    }

    input InputFilter {
        pagination: IPaginationInput!
    }

    input IPaginationInput {
        limit: Int!
        offset: Int!
    }

    type IPagination {
        limit: Int
        offset: Int   
    }

`;