import { Role } from "../../../Common/constants"

export const BusinessProfileActions = {
  Query: {
    fetchAll: "fetchBusinessProfiles", fetchOneByID: "fetchOneBusinessProfileByID", fetchManyByID: "fetchManyBusinessProfilesByID",
  },
  Mutation: {
    post: "createBusinessProfile", edit: "updateBusinessProfile",
    removeOne: "removeOneBusinessProfile", removeMany: "removeManyBusinessProfiles", removeAll: "removeAllBusinessProfiles"
  }
}

export const getAllowedActions = (role: Role) => {
  switch (role) {
    case Role.TESTING:
      return [
        ...Object.values(BusinessProfileActions.Query),
        ...Object.values(BusinessProfileActions.Mutation)
      ]
      
    case Role.ADMIN:
      return [
        ...Object.values(BusinessProfileActions.Query), BusinessProfileActions.Mutation.removeOne,
        BusinessProfileActions.Mutation.post, BusinessProfileActions.Mutation.edit, BusinessProfileActions.Mutation.removeMany
      ]

    case Role.USER:
      return [
        BusinessProfileActions.Query.fetchOneByID,
        BusinessProfileActions.Mutation.edit
      ]

    case Role.PUBLIC_USER:
      return []
    default:
      return []
  }
}
