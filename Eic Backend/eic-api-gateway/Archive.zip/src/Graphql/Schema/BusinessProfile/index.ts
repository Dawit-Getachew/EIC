import { gql } from "apollo-server-express"
import { BusinessProfileActions } from "./action"

const {
  Query: { fetchAll, fetchManyByID, fetchOneByID },
  Mutation: { edit, post, removeAll, removeMany, removeOne }
} = BusinessProfileActions

export default gql`
  extend type Query {
    ${fetchAll}: [IBusinessProfile]
    ${fetchOneByID}(_id: ID!): IBusinessProfile
    ${fetchManyByID}(_ids: [ID!]!): [IBusinessProfile]
  }

  extend type Mutation {
    ${post}(input: IBusinessProfileInput): IBusinessProfileResponse
    ${edit}(input: IBusinessProfileEdit): IBusinessProfileResponse
    ${removeOne}(_id: ID!): IBusinessProfile
    ${removeMany}(_ids: [ID!]!): [IBusinessProfile]
    ${removeAll}: String
  }

  union IBusinessProfileResponse = IBusinessProfileSimple | SystemError | ValidationError | ValidationErrors

  type IBusinessProfile {
    _id: ID
    legal_status: LegalStatusTypes
    form_of_ownership: FormOfOwnerShipTypes
    company_of_incorporation: String
    company_name: String
    company_name_amharic: String
    address: IBusinessAddress
    tin_number: String
    registration_number: String
    createdAt: Date
    updatedAt: Date
  }

  type IBusinessProfileSimple {
    _id: ID
    legal_status: LegalStatusTypes
    form_of_ownership: FormOfOwnerShipTypes
    company_of_incorporation: String
    company_name: String
    company_name_amharic: String
    address: IBusinessAddress
    tin_number: String
    registration_number: String
    createdAt: Date
    updatedAt: Date
  }                                                                                                                                                                                    

  input IBusinessProfileInput {
    legal_status: LegalStatusTypes!
    form_of_ownership: FormOfOwnerShipTypes!
    company_of_incorporation: String!
    company_name: String!
    company_name_amharic: String!
    address: InputBusinessAddress!
    tin_number: String!
    registration_number: String!
  }

  input IBusinessProfileEdit {
    _id: ID!
    legal_status: LegalStatusTypes
    form_of_ownership: FormOfOwnerShipTypes
    company_of_incorporation: String
    company_name: String
    company_name_amharic: String
    address: InputBusinessAddress
    tin_number: String
    registration_number: String
  }

  type IBusinessAddress {
    region: String
    zone: String
    wereda: String
    kebele: String
    house_number: String
    email: String
    telephone_direct: String
    telephone_mobile: String
    fax: String
    po_box: String
    other_address: String
  }

  input InputBusinessAddress {
    region: String!
    zone: String!
    wereda: String!
    kebele: String!
    house_number: String!
    email: String!
    telephone_direct: String!
    telephone_mobile: String!
    fax: String!
    po_box: String!
    other_address: String
  }

  enum LegalStatusTypes {
    Sole_Proprietorship
    Private_Limited_Company
    Share_Company
    Public_Enterprise
    Cooperative_Society
  }
  
  enum FormOfOwnerShipTypes {
    Domestic_Investor
    Foreign_Investor
    As_Domestic_Investor
    Joint_Investment
    Branch
  }

`