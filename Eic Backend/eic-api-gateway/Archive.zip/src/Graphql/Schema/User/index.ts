import { gql } from "apollo-server-express"
import { UserActions } from "./action"

const {
  Query: { fetchAll, fetchManyByID, fetchOneByID },
  Mutation: { edit, login, logout, post, removeAll, removeMany, removeOne }
} = UserActions

export default gql`
  extend type Query {
    ${fetchAll}: [IUser]
    ${fetchOneByID}(_id: ID!): IUser
    ${fetchManyByID}(_ids: [ID!]!): [IUser]
  }

  extend type Mutation {
    ${post}(input: IUserInput): IUserResponse
    ${edit}(input: IUserEdit): IUserResponse
    ${removeOne}(_id: ID!): IUser
    ${removeMany}(_ids: [ID!]!): [IUser]
    ${removeAll}: String
    ${login}(input: IUserSignin): IUserResponse
    ${logout}: ISignOutResponse
  }

  union IUserResponse = IUserSimple | SystemError | ValidationError | ValidationErrors | Message | UnAuthenticatedError | IUser
  union ISignOutResponse = Message | UnAuthenticatedError

  type IUser {
    _id: ID
    first_name: String
    middle_name: String
    last_name: String
    email: String
    gender: Gender
    role: String
    phone_number: String
    business_profile: String
    service_id: String
    createdAt: Date
    updatedAt: Date
  }

  type IUserSimple {
    _id: ID
    first_name: String
    middle_name: String
    last_name: String
    email: String
    gender: Gender
    role: String
    phone_number: String
    business_profile: String
    service_id: String
    createdAt: Date
    updatedAt: Date
  }                                                                                                                                                                                    

  input IUserInput {
    first_name: String!
    middle_name: String!
    last_name: String!
    email: String!
    gender: Gender!
    role: IRole!
    phone_number: String!
    password: String!
  }

  input IUserEdit {
    _id: ID!
    first_name: String
    last_name: String
    email: String
    phone_number: String
    service_id: ID
  }

  input IUserSignin {
    phone_number: String!
    password: String!
  }

`